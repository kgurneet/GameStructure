/**
 * ACS-3913 - Assignment 4
 */
/*
 * @author Gurneet Kaur
 * #3152692
 */
import java.util.ArrayList;

public class Folder extends FileComponent {
    private ArrayList<FileComponent> contents;

    public Folder(String n){
        name = n;
        contents = new ArrayList<>();
    }
    
    public void addFileComponent(FileComponent fc){
        contents.add(fc);
        fc.setParent(this);
    }
    
    public void display(String indent) {
        indent += "--";
        System.out.println(indent + "Folder: "+name);
        for(FileComponent fileComponent: contents){
            fileComponent.display(indent);
        }
    }

    public String toString(){
        return name;
    }

    public int getSize(){
        int size = 0;
        for(FileComponent fileComponent: contents){
            size += fileComponent.getSize();
            }
        return size;
    }


    public String getPath(){
        StringBuilder sb= new StringBuilder(name);
        FileComponent current= parent;
        while(current != null){
            sb.insert(0, current.getName() + "/");
            current = current.getParent();
            }
            return sb.toString();
            }

            public void accept(Visitor v){
                v.visit(this);
            }
        
            public ArrayList<FileComponent> getFileComponents(){
                return contents;
            }
    }
