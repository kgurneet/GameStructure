/*
 * @author Gurneet Kaur
 * #3152692
 */
public class BackupVisitor implements Visitor {

    public void visit(Folder fd){
        System.out.println();
        System.out.println("Backing up folder "+fd.getName()+" contents:");
        for(FileComponent fileComponent: fd.getFileComponents()){
            fileComponent.accept(this);
        }
    }

    public void visit(File f){
        System.out.println("Backing up file "+f.getName()+" contents...");
    }
    
}
