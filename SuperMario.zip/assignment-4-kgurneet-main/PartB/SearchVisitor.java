/*
 * @author Gurneet Kaur
 * #3152692
 */
public class SearchVisitor implements Visitor {
    private String item;

    public void setItem(String item){this.item = item.toLowerCase();}

    public void visit(Folder fd){
        for(FileComponent fileComponent: fd.getFileComponents()){
            fileComponent.accept(this);
        }
    } 

    public void visit(File f){
        if(f.getName().toLowerCase().contains(item)|| f.getData().toLowerCase().contains(item) ){
            System.out.println(f.getPath());
        }
    }
}
