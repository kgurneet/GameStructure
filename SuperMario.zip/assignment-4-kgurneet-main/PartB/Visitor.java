/*
 * @author Gurneet Kaur
 * #3152692
 */
public interface Visitor {
    
    void visit(File f);

    void visit(Folder fd);
}
