/*
 * @author Gurneet Kaur
 * #3152692
 */
public class GiantPiranhaPlant implements PiranhaPlantSpecies {

    public String toString(){
    return "Giant Piranha Plant";
}
    
}
