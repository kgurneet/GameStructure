/*
 * @author Gurneet Kaur
 * #3152692
 */
import java.util.ArrayList;
import java.util.List;

public class Level2 extends GameLevel {

    public Level2(int num,EnemyFactory e){
        super(num,e);
        setEnvironment("classrooms, cafeteria, security, escalators");
        setName(e.toString()+" Level "+ num);
    }

    public List<Enemy> createEnemies(){
        List<Enemy> enemies = new ArrayList<Enemy>();
        for(int i=0; i<7; i++){
            enemies.add(e.createGoomba());}
        for (int i = 0; i < 8; i++) {
            enemies.add(e.createPiranhaPlant());
            }
        for(int i=0 ; i<15;i++){
            enemies.add(e.createKoopaTroopa());
            }
            return enemies;
}

    public String toString(){
        return "";
    }
}
