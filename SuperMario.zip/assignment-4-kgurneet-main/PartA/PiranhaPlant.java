/*
 * @author Gurneet Kaur
 * #3152692
 */
public class PiranhaPlant implements PiranhaPlantSpecies{

    public String toString(){
        return "Piranha Plant";
    }
    
}
