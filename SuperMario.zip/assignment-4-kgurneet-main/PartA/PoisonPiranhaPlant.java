/*
 * @author Gurneet Kaur
 * #3152692
 */
public class PoisonPiranhaPlant implements PiranhaPlantSpecies{

    public String toString(){
        return "Poison Piranha Plant";
    }
    
}
