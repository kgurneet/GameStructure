/*
 * @author Gurneet Kaur
 * #3152692
 */
public class CentennialHall extends GameWorld{

    protected EnemyFactory getEnemyFactory(){
        return new CentennialHallEnemyFactory();
    }

    protected GameLevel createLevel(int num){
     switch (num) {
            case 1: return new Level1(num, getEnemyFactory());
            case 2: return new Level2(num, getEnemyFactory());
            case 3: return new Level3(num, getEnemyFactory());
            default: return null;
     }
    }
    
}
