/*
 * @author Gurneet Kaur
 * #3152692
 */
import java.util.List;

public abstract class GameLevel {

    protected String name;
    protected int num;
    protected String environment;
    protected EnemyFactory e;
    protected List<Enemy> enemies;

    public GameLevel(int num, EnemyFactory e){
        this.num = num;
        this.e = e;
    }

    public abstract List<Enemy> createEnemies();

    public void renderEnemies(){
        System.out.println("Rendering enemies...");
    } 

    public void spawnEnemies(){
        System.out.println("Spawning enemies: ");
        for (int i=0; i<createEnemies().size();i++) {
           System.out.print(createEnemies().get(i));
            if(i<createEnemies().size()-1){
            System.out.print(", ");
            }
            }
            System.out.println();
    }

    public void renderEnvironment(){
        System.out.println("Rendering environment: " + environment);
    }

    public String getName(){return name;}

    public void setName(String name){this.name=name;}

    public String getEnvironment(){return environment;}

    public void setEnvironment(String environment){this.environment=environment;}

    
}
