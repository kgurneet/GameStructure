/*
 * @author Gurneet Kaur
 * #3152692
 */
public class Galoomba implements GoombaSpecies{

    public String toString(){
        return "Galoomba";
    }
    
}
