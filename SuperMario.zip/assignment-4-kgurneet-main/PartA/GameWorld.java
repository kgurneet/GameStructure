/*
 * @author Gurneet Kaur
 * #3152692
 */
public abstract class GameWorld {

    protected abstract EnemyFactory getEnemyFactory();

    protected abstract GameLevel createLevel(int num);

    public GameLevel playLevel(int num){

        GameLevel level = createLevel(num);
        System.out.println("*** Setting up "+level.getName()+ level+" ***");
        level.renderEnvironment();
        level.renderEnemies();
        level.spawnEnemies();
        level.createEnemies();
        System.out.println("*** Completed playing "+level.getName()+ level+" ***");
        return level;
     
    }
    
}
