/**
 * ACS-3913 - Assignment 4
 */
/*
 * @author Gurneet Kaur
 * #3152692
 */
public interface GoombaSpecies extends Enemy{
  public String toString();
}
