/*
 * @author Gurneet Kaur
 * #3152692
 */
public class DryBonesKoopa implements KoopaTroopaSpecies{

    public String toString(){
        return "Dry Bones Koopa";
    }
    
}
