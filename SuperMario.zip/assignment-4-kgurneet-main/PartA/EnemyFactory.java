/*
 * @author Gurneet Kaur
 * #3152692
 */
/**
 * ACS-3913 - Assignment 4
 */

public interface EnemyFactory{
    public PiranhaPlantSpecies createPiranhaPlant();
    
    public GoombaSpecies createGoomba();
    
    public KoopaTroopaSpecies createKoopaTroopa();
}
