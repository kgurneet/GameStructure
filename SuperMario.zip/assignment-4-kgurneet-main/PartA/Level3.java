/*
 * @author Gurneet Kaur
 * #3152692
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Level3 extends GameLevel {

    public Level3(int num,EnemyFactory e){
        super(num,e);
        setEnvironment("lecture halls, classrooms, The Hive");
        setName(e.toString()+" Level "+ num);
    }

    public List<Enemy> createEnemies(){
        List<Enemy> enemies = new ArrayList<Enemy>();
        for (int i = 0; i < 12; i++) {
            enemies.add(e.createPiranhaPlant());
            enemies.add(e.createKoopaTroopa());
            enemies.add(e.createGoomba());
            }
        Collections.shuffle(enemies);
            return enemies;
    }

    public String toString(){
        return "";
    }
    
}
