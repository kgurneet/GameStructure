/**
 * ACS-3913 - Assignment 4
 */
/*
 * @author Gurneet Kaur
 * #3152692
 */
public interface KoopaTroopaSpecies extends Enemy{
    public String toString();
}