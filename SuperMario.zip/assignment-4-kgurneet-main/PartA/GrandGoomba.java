/*
 * @author Gurneet Kaur
 * #3152692
 */
public class GrandGoomba implements GoombaSpecies {

    public String toString(){
        return "Grand Goomba";
    }
}
