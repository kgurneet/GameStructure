/*
 * @author Gurneet Kaur
 * #3152692
 */
public class SuperKoopa implements KoopaTroopaSpecies {
    public String toString(){
        return "Super Koopa";
    }
    
}
