/*
 * @author Gurneet Kaur
 * #3152692
 */
import java.util.ArrayList;
import java.util.List;

public class Level1 extends GameLevel {

    public Level1(int num,EnemyFactory e){
        super(num,e);
        setEnvironment("classrooms, labs, fitness facility, gym");
        setName(e.toString()+ " Level "+num);
        }

    public List<Enemy> createEnemies(){
        List<Enemy> enemies = new ArrayList<Enemy>();
        for (int i = 0; i < 7; i++) {
            enemies.add(e.createPiranhaPlant());
            }
        for(int i=0 ; i<7;i++){
            enemies.add(e.createKoopaTroopa());
            }
        for(int i=0; i<7; i++){
            enemies.add(e.createGoomba());}
            return enemies;
}

 public String toString(){
    return "";
 }
    
}
