/*
 * @author Gurneet Kaur
 * #3152692
 */
public class KoopaTroopa implements KoopaTroopaSpecies{

    public String toString(){
        return "Koopa Troopa";
    }
    
}
