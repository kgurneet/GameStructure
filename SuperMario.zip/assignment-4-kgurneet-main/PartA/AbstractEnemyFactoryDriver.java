/**
 * ACS-3913 - Assignment 4
 */
/*
 * @author Gurneet Kaur
 * #3152692
 */
public class AbstractEnemyFactoryDriver{
    public static void main(String[] args){
        EnemyFactory def = new DuckworthCentreEnemyFactory();
        System.out.println("Duckworth Centre Enemies: ");
        System.out.println(def.createPiranhaPlant());
        System.out.println(def.createGoomba());
        System.out.println(def.createKoopaTroopa());       
        
        EnemyFactory cef = new CentennialHallEnemyFactory();
        System.out.println("\nCentennial Hall Enemies: ");
        System.out.println(cef.createPiranhaPlant());
        System.out.println(cef.createGoomba());
        System.out.println(cef.createKoopaTroopa());  
        
        EnemyFactory lef = new LockhartHallEnemyFactory();
        System.out.println("\nLockhart Hall Enemies: ");
        System.out.println(lef.createPiranhaPlant());
        System.out.println(lef.createGoomba());
        System.out.println(lef.createKoopaTroopa());  
    }
}
