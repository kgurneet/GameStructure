/*
 * @author Gurneet Kaur
 * #3152692
 */
public class Goomba implements GoombaSpecies{

    public String toString(){
        return "Goomba";
    }
    
}
