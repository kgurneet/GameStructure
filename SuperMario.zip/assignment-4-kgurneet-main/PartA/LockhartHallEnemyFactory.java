/*
 * @author Gurneet Kaur
 * #3152692
 */
public class LockhartHallEnemyFactory implements EnemyFactory{


    public PiranhaPlantSpecies createPiranhaPlant() {
        return new GiantPiranhaPlant();
            }

    public GoombaSpecies createGoomba() {
      return new GrandGoomba();
      }

    public KoopaTroopaSpecies createKoopaTroopa() {
      return new SuperKoopa();
        }

        public String toString(){
          return "Lockhart Hall";
        }
    
}
